# FocusMate — Android starter project

An original, local-first focus/Pomodoro app inspired by the general digital-wellbeing category. It does not copy Regain branding or proprietary assets.

## Included in this starter
- Native Android app using Kotlin + Jetpack Compose
- Focus timer, pause/reset, configurable focus and break durations
- Local session totals, history, streak counter and simple milestone reward
- Daily reminder scheduling (Android notification permission/settings may be required)
- JSON manual export and restore using Android's file picker
- Local text fields for app package IDs and website domains
- Accessibility service declaration scaffold for a future app-blocking implementation
- No account, analytics SDK, or cloud sync

## Important limitations — read before relying on it
- **App blocking is not enforced in this starter.** The AccessibilityService is a scaffold and intentionally does not redirect/stop apps. A real implementation needs careful foreground-package handling, explicit user opt-in, accessibility disclosure, testing across Android versions, and review against Google Play policy.
- **Website blocking is not implemented.** The app saves domain lists locally only. Reliable device-wide blocking generally requires a user-approved local VPN/DNS filter and lifecycle/permission handling; this starter does not filter network traffic.
- Reminder scheduling is a basic starter; Android may delay inexact alarms. Notification permission may need to be granted in system settings.
- This project source has not been built or tested on a physical phone in this environment. Treat it as a starter project, not a ready-to-install APK.

## Build an APK
1. Install Android Studio on a computer (Windows, macOS, or Linux) and the Android SDK Platform 35.
2. Open this `FocusMateAndroid` folder in Android Studio.
3. Let Gradle sync and resolve dependencies while connected to the internet.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output location. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## Local storage and backup
Progress/settings are stored in app-private SharedPreferences on the phone. Use Settings > Export manual backup to save JSON using Android's file picker. Restore imports a JSON backup into this app. Keep backups private; they include progress and any package/domain lists entered.

## Suggested next development milestones
1. Implement and test app blocking with an explicit blocklist and clear opt-in UX.
2. Implement website blocking with a local `VpnService`, a visible persistent notification, and an explicit VPN consent screen.
3. Add editable reminder times, a weekly chart, focus schedule persistence, and robust timer state recovery after process death.
4. Add automated tests, accessibility checks, privacy disclosures, app icon, and release signing.
