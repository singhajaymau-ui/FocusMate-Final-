package com.focusmate.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private val forest = Color(0xFF17382B)
private val mint = Color(0xFFBFF2CE)
private val cream = Color(0xFFF5F7F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FocusMateApp() } }
}

@Composable
private fun FocusMateApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("focusmate_local", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var focusMinutes by remember { mutableIntStateOf(25) }
    var breakMinutes by remember { mutableIntStateOf(5) }
    var secondsLeft by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Focus") }
    var totalMinutes by remember { mutableIntStateOf(prefs.getInt("total_minutes", 0)) }
    var sessions by remember { mutableIntStateOf(prefs.getInt("sessions", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
    var lastDay by remember { mutableStateOf(prefs.getString("last_day", "") ?: "") }
    var history by remember { mutableStateOf(prefs.getString("history", "[]") ?: "[]") }
    var blockedPackages by remember { mutableStateOf(prefs.getString("blocked_packages", "") ?: "") }
    var websites by remember { mutableStateOf(prefs.getString("blocked_sites", "") ?: "") }
    var showBlockInfo by remember { mutableStateOf(false) }
    var showWebsiteInfo by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are.") }

    LaunchedEffect(running, secondsLeft) {
        while (running && secondsLeft > 0) { delay(1000); secondsLeft -= 1 }
        if (running && secondsLeft <= 0) {
            running = false
            if (mode == "Focus") {
                val nowDay = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val newStreak = if (lastDay == nowDay) streak else if (lastDay == yesterday()) streak + 1 else 1
                totalMinutes += focusMinutes; sessions += 1; streak = newStreak; lastDay = nowDay
                val arr = JSONArray(history); val item = JSONObject().put("date", nowDay).put("minutes", focusMinutes).put("time", System.currentTimeMillis()); arr.put(item); history = arr.toString()
                prefs.edit().putInt("total_minutes", totalMinutes).putInt("sessions", sessions).putInt("streak", streak).putString("last_day", lastDay).putString("history", history).apply()
                status = "Session complete — great work!"
                mode = "Break"; secondsLeft = breakMinutes * 60
            } else { mode = "Focus"; secondsLeft = focusMinutes * 60; status = "Break finished. Ready for another round?" }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportJson(totalMinutes, sessions, streak, lastDay, history, blockedPackages, websites)) }; status = "Backup exported." } catch (e: Exception) { status = "Backup failed: ${e.message}" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try { val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""; val obj = JSONObject(raw); totalMinutes = obj.optInt("totalMinutes"); sessions = obj.optInt("sessions"); streak = obj.optInt("streak"); lastDay = obj.optString("lastDay"); history = obj.optJSONArray("history")?.toString() ?: "[]"; blockedPackages = obj.optString("blockedPackages"); websites = obj.optString("websites"); prefs.edit().putInt("total_minutes",totalMinutes).putInt("sessions",sessions).putInt("streak",streak).putString("last_day",lastDay).putString("history",history).putString("blocked_packages",blockedPackages).putString("blocked_sites",websites).apply(); status = "Backup restored on this phone." } catch (e: Exception) { status = "Could not restore that file." }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = forest, secondary = mint, background = cream, surface = Color.White)) {
        Scaffold(containerColor = cream, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Focus", "Progress", "Block", "Settings").forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("◷", "▥", "⊘", "⚙")[i], fontSize = 18.sp) }, label = { Text(label) }) }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp)) {
                item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("FocusMate", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = forest); Text("Your time. Your focus. Your progress.", color = Color(0xFF607267)) }; Text("● PRIVATE", color = forest, fontSize = 11.sp, fontWeight = FontWeight.Bold) } }
                when (tab) {
                    0 -> {
                        item { Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = forest), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${mode.uppercase()} SESSION", color = mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(18.dp)); Text(String.format(Locale.US, "%02d:%02d", secondsLeft / 60, secondsLeft % 60), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
                            Text(if (mode == "Focus") "Stay with one thing." else "Rest your mind." , color = Color(0xFFD6E8DC))
                            Spacer(Modifier.height(22.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { running = !running; status = if (running) "Timer running." else "Timer paused." }, colors = ButtonDefaults.buttonColors(containerColor = mint, contentColor = forest)) { Text(if (running) "Pause" else "Start focus") }; OutlinedButton(onClick = { running = false; mode = "Focus"; secondsLeft = focusMinutes * 60; status = "Timer reset." }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Reset") } }
                        } } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp)) { Text("Pomodoro settings", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Focus: $focusMinutes min", color = forest); Slider(value = focusMinutes.toFloat(), onValueChange = { focusMinutes = it.toInt(); if (!running && mode == "Focus") secondsLeft = focusMinutes * 60 }, valueRange = 5f..60f, steps = 10); Text("Break: $breakMinutes min", color = forest); Slider(value = breakMinutes.toFloat(), onValueChange = { breakMinutes = it.toInt(); if (!running && mode == "Break") secondsLeft = breakMinutes * 60 }, valueRange = 1f..15f, steps = 13); OutlinedButton(onClick = { mode = if (mode == "Focus") "Break" else "Focus"; running = false; secondsLeft = (if (mode == "Focus") focusMinutes else breakMinutes) * 60 }) { Text("Switch to ${if (mode == "Focus") "break" else "focus"}") } } } }
                        item { Text(status, color = forest) }
                    }
                    1 -> {
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("FOCUS MINUTES", totalMinutes.toString(), Modifier.weight(1f)); StatCard("SESSIONS", sessions.toString(), Modifier.weight(1f)) } }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("DAY STREAK", "🔥 $streak", Modifier.weight(1f)); StatCard("REWARD", if (sessions >= 10) "Focus Pro" else "${sessions}/10", Modifier.weight(1f)) } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp)) { Text("Recent focus sessions", fontWeight = FontWeight.Bold, fontSize = 18.sp); val arr = remember(history) { try { JSONArray(history) } catch (_: Exception) { JSONArray() } }; if (arr.length() == 0) Text("Your completed sessions will appear here.", color = Color.Gray) else for (i in (arr.length()-1 downTo maxOf(0, arr.length()-7))) { val obj = arr.optJSONObject(i); Text("• ${obj?.optString("date")} — ${obj?.optInt("minutes")} minutes") } } } }
                    }
                    2 -> {
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Distraction blocking", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Choose apps to block during focus. Android requires you to enable FocusMate's Accessibility service before app blocking can work.", color = Color.DarkGray); OutlinedTextField(value = blockedPackages, onValueChange = { blockedPackages = it; prefs.edit().putString("blocked_packages", it).apply() }, label = { Text("Blocked app package IDs") }, placeholder = { Text("com.example.socialapp, ...") }, modifier = Modifier.fillMaxWidth(), minLines = 2); Button(onClick = { try { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {} }, modifier = Modifier.fillMaxWidth()) { Text("Open Accessibility settings") }; Text("Example package IDs can be found in Android app details/tools. This starter service is a scaffold; see README before relying on blocking.", fontSize = 12.sp, color = Color.Gray) } } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Website blocking", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Website blocking needs a local VPN/DNS filtering component. This starter stores your block list locally but does not yet filter traffic.", color = Color.DarkGray); OutlinedTextField(value = websites, onValueChange = { websites = it; prefs.edit().putString("blocked_sites", it).apply() }, label = { Text("Domains to block") }, placeholder = { Text("social.example, video.example") }, modifier = Modifier.fillMaxWidth(), minLines = 2); Text("Saved only on this device. Website blocking is not active in this starter build.", color = Color(0xFF8A4C00), fontSize = 12.sp) } } }
                    }
                    else -> {
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("On-device privacy", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("FocusMate stores progress in app-private local storage. No account, analytics SDK, or cloud sync is included."); Button(onClick = { exportLauncher.launch("focusmate-backup.json") }, modifier = Modifier.fillMaxWidth()) { Text("Export manual backup (JSON)") }; OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Restore backup from file") }; Text("Keep your backup somewhere safe. Restoring replaces current progress and settings.", color = Color.Gray, fontSize = 12.sp) } } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Daily reminders", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Set a daily reminder for 7:00 PM. Notification permission may be requested by Android."); Button(onClick = { scheduleReminder(context); status = "Daily reminder scheduled for 7:00 PM." }) { Text("Schedule 7 PM reminder") }; Text(status, color = forest) } } }
                        item { Text("Version 1.0 starter · English · Local-first", color = Color.Gray, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(label, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 26.sp, color = forest, fontWeight = FontWeight.Bold) } } }

private fun yesterday(): String { val cal = java.util.Calendar.getInstance(); cal.add(java.util.Calendar.DAY_OF_YEAR, -1); return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time) }
private fun exportJson(minutes: Int, sessions: Int, streak: Int, lastDay: String, history: String, packages: String, sites: String): String = JSONObject().put("formatVersion", 1).put("totalMinutes", minutes).put("sessions", sessions).put("streak", streak).put("lastDay", lastDay).put("history", JSONArray(history)).put("blockedPackages", packages).put("websites", sites).toString(2)

private fun scheduleReminder(context: Context) {
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = android.app.PendingIntent.getBroadcast(context, 7001, intent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
    val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 19); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1) }
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
    if (android.os.Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
    else alarm.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, android.app.AlarmManager.INTERVAL_DAY, pending)
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(android.app.NotificationChannel("focusmate_reminders", "Focus reminders", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        val notification = if (android.os.Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, "focusmate_reminders") else @Suppress("DEPRECATION") android.app.Notification.Builder(context)
        manager.notify(7001, notification.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Time for a focus session").setContentText("A few focused minutes can move you forward.").setAutoCancel(true).build())
    }
}

class AppGuardAccessibilityService : android.accessibilityservice.AccessibilityService() {
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        // Starter scaffold: intentionally does not force-close apps until the user configures a tested blocking policy.
        // See README for the implementation and permission review needed before enabling enforcement.
    }
    override fun onInterrupt() {}
}
